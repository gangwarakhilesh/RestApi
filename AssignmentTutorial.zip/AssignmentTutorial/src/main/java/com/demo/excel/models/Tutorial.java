package com.demo.excel.models;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

@Entity
@Table(name = "tutorials")
public class Tutorial {

	@Id
	@GeneratedValue
	private int uid;
	private String fullName;
	private String deliverName;
	private String fullAddress;
	private String pan;
	private String otherInfo;
	
	@Transient
	public List<Address> address;
	
	private String listedOn;
	
	
    @Transient
	private List<IndividualDocument> individualDocument;
    
    
	public int getUid() {
		return uid;
	}
	public void setUid(int uid) {
		this.uid = uid;
	}
	public String getFullName() {
		return fullName;
	}
	public void setFullName(String fullName) {
		this.fullName = fullName;
	}
	public String getDeliverName() {
		return deliverName;
	}
	public void setDeliverName(String deliverName) {
		this.deliverName = deliverName;
	}
    
	public String getListedOn() {
		return listedOn;
	}
	public void setListedOn(String listedOn) {
		this.listedOn = listedOn;
	}
	
	
	
	public String getOtherInfo() {
		return otherInfo;
	}
	public void setOtherInfo(String otherInfo) {
		this.otherInfo = otherInfo;
	}
	public String getFullAddress() {
		return fullAddress;
	}
	public void setFullAddress(String fullAddress) {
		this.fullAddress = fullAddress;
	}
	public String getPan() {
		return pan;
	}
	public void setPan(String pan) {
		this.pan = pan;
	}

	public void setAddress(List<Address> address) {
		this.address = address;
	}

	public List<Address> getAddress() {
		return address;
	}
	public List<IndividualDocument> getIndividualDocument() {
		return individualDocument;
	}
	public void setIndividualDocument(List<IndividualDocument> individualDocument) {
		this.individualDocument = individualDocument;
	}
	
	
	

}
