package com.demo.excel.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.demo.excel.models.Tutorial;

public interface TutorialRepository extends JpaRepository<Tutorial, Long> {
}
