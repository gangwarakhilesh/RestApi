package com.demo.excel;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AssignmentTutorialApplication {

	public static void main(String[] args) {
		SpringApplication.run(AssignmentTutorialApplication.class, args);
	}

}
