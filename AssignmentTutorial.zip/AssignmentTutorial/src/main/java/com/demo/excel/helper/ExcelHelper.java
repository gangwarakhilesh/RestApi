package com.demo.excel.helper;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.LinkedHashMap;
import java.util.List;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.demo.excel.models.IndividualDocument;
import com.demo.excel.models.Tutorial;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

public class ExcelHelper {
  public static String TYPE = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
  static String[] HEADERs = { "OrderDate", "OrderParticulars", "Entity/IndividualName", "PAN" };
  static String SHEET = "Tutorials";
  static ObjectMapper object=new ObjectMapper();
  
  public static ByteArrayInputStream tutorialsToExcel(List<Tutorial> tutorials) {

    try (Workbook workbook = new XSSFWorkbook(); ByteArrayOutputStream out = new ByteArrayOutputStream();) {
      Sheet sheet = workbook.createSheet(SHEET);
      
 

      // Header
      Row headerRow = sheet.createRow(0);

      for (int col = 0; col < HEADERs.length; col++) {
        Cell cell = headerRow.createCell(col);
        cell.setCellValue(HEADERs[col]);
      }

      int rowIdx = 1;
      for (Tutorial tutorial : tutorials) {
    	  List<LinkedHashMap> individualDocument =null;
    	  individualDocument =  object.readValue(tutorial.getPan(),List.class);
        Row row = sheet.createRow(rowIdx++);
        

        row.createCell(0).setCellValue(tutorial.getListedOn());
        row.createCell(1).setCellValue(tutorial.getOtherInfo());
        row.createCell(2, CellType.STRING).setCellValue(tutorial.getFullAddress());
        row.createCell(3,CellType.STRING).setCellValue(individualDocument.get(0).get("number").toString());
      }

      workbook.write(out);
      return new ByteArrayInputStream(out.toByteArray());
    } catch (IOException e) {
      throw new RuntimeException("fail to import data to Excel file: " + e.getMessage());
    }
  }

}
