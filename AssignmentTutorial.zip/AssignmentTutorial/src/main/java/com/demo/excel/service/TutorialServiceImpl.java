package com.demo.excel.service;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Service;

import com.demo.excel.models.Tutorial;
import com.demo.excel.repository.TutorialRepository;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;


@Service
public class TutorialServiceImpl implements TutorialService {
	
	ObjectMapper object = new ObjectMapper();
	
	@Autowired
	public TutorialRepository  repository;

	@Override
	public void saveTutorial(Tutorial tutorial) {
		
		try {
			tutorial.setFullAddress(object.writeValueAsString(tutorial.address));
			tutorial.setPan(object.writeValueAsString(tutorial.getIndividualDocument()));
		} catch (JsonProcessingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		repository.save(tutorial);
		
	}

	

}
