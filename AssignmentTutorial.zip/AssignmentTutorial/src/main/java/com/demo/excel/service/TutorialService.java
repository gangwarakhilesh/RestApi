package com.demo.excel.service;

import org.springframework.stereotype.Service;

import com.demo.excel.models.Tutorial;


@Service
public interface TutorialService {

	void saveTutorial(Tutorial tutorial);

}
