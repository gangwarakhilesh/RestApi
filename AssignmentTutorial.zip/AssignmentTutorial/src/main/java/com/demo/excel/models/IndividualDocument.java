package com.demo.excel.models;

public class IndividualDocument {
	
	private String typeOfDocument;
	private String number;
	public String getTypeOfDocument() {
		return typeOfDocument;
	}
	public void setTypeOfDocument(String typeOfDocument) {
		this.typeOfDocument = typeOfDocument;
	}
	public String getNumber() {
		return number;
	}
	public void setNumber(String number) {
		this.number = number;
	}
	@Override
	public String toString() {
		return "IndividualDocument [typeOfDocument=" + typeOfDocument + ", number=" + number + "]";
	}
	
	

}
