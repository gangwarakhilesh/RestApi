package com.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.demo.models.Employee;
import com.demo.repository.EmployeeDao;

@Service
public class EmployeeServiceImpl implements EmployeeService
{
	@Autowired
	public EmployeeDao dao;

	public void saveEmployee(Employee employee)
	{
		dao.save(employee);
		
	}

	public List<Employee> getEmployee()
	{
		return dao.findAll();
		
	
	}

	public Employee getEmployeeId(int eid)
	{
		Employee employee=dao.findById(eid).orElse(null);
		return employee;
		
	}

	public void deleteEmployee(int eid) 
	{
		dao.deleteById(eid);
		
	}

	public void updateEmployee(Employee employee) 
	{
		dao.save(employee);
		
	}
}
