package com.demo.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.demo.models.Employee;

@Service
public interface EmployeeService
{

	void saveEmployee(Employee employee);

	List<Employee> getEmployee();

	Employee getEmployeeId(int eid);

	void deleteEmployee(int eid);

	void updateEmployee(Employee employee);



}
