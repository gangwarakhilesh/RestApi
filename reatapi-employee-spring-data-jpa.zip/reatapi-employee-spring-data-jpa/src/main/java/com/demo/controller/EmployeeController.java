package com.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.demo.models.Employee;
import com.demo.service.EmployeeService;

@RestController
@RequestMapping("/employee")
public class EmployeeController
{
	@Autowired
	public EmployeeService service;
	
	@PostMapping
	public String addEmployee(@RequestBody Employee employee)
	{
		service.saveEmployee(employee);
		return "resource created";
	}
	@GetMapping
	public List<Employee> getEmployee()
	{
		List<Employee> list=service.getEmployee();
		return list;
	}
	@GetMapping("{eid}")
	public Employee getEmployeeId(@PathVariable int eid)
	{
		Employee employee=service.getEmployeeId(eid);
		return employee;
	}
	@DeleteMapping("{eid}")
	public Employee deleteEmployee(@PathVariable int eid)
	{
		Employee employee=service.getEmployeeId(eid);
		if(employee!=null)
		{
			service.deleteEmployee(eid);
		}
		return employee;
	}
	@PutMapping("{eid}")
	public String updatEmployee(@RequestBody Employee employee,@PathVariable int eid)
	{
		Employee emp=service.getEmployeeId(eid);
		employee.setEid(eid);
		service.updateEmployee(employee);
		if(emp!=null)
		{
			return "Employee resource created";	
		}
		return "Employee resource updated";
	}

}
